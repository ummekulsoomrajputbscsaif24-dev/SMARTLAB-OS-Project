
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

#define REQUEST_FIFO "/tmp/smartlab_request"
#define RESPONSE_SIZE 1024

typedef struct {
    char action[16];
    int student_id;
    int pc_number;
    char response_fifo[128];
} Request;

int main(void)
{
    Request req = {0};
    char response[RESPONSE_SIZE] = {0};

    int choice;
    int request_fd;
    int response_fd;

    printf("\n====================================\n");
    printf("          SMARTLAB CLIENT           \n");
    printf("====================================\n");

    printf("1. Request a computer\n");
    printf("2. Release a computer\n");
    printf("3. View laboratory status\n");
    printf("0. Exit\n");

    printf("\nEnter choice: ");

    if (scanf("%d", &choice) != 1) {
        printf("Invalid menu input.\n");
        return 1;
    }

    if (choice == 0) {
        printf("Goodbye.\n");
        return 0;
    }

    if (choice < 1 || choice > 3) {
        printf("Invalid menu choice.\n");
        return 1;
    }

    // Select action
    if (choice == 1) {
        strcpy(req.action, "REQUEST");
    }
    else if (choice == 2) {
        strcpy(req.action, "RELEASE");
    }
    else {
        strcpy(req.action, "STATUS");
    }

   // Student ID is required only for request and release
req.student_id = 0;

if (choice != 3) {
    printf("Enter Student ID: ");

    if (scanf("%d", &req.student_id) != 1 ||
        req.student_id <= 0) {
        printf("Invalid student ID.\n");
        return 1;
    }
}
    // PC number is required for request and release
    req.pc_number = 0;

    if (choice != 3) {

        printf("Enter PC number (1-5): ");

        if (scanf("%d", &req.pc_number) != 1) {
            printf("Invalid PC number.\n");
            return 1;
        }

        if (req.pc_number < 1 || req.pc_number > 5) {
            printf("PC number must be between 1 and 5.\n");
            return 1;
        }
    }

    // Create unique response FIFO
    snprintf(
        req.response_fifo,
        sizeof(req.response_fifo),
        "/tmp/smartlab_response_%ld",
        (long)getpid()
    );

    unlink(req.response_fifo);

    if (mkfifo(req.response_fifo, 0600) == -1) {
        perror("Create response FIFO");
        return 1;
    }

    // Connect to server
    request_fd = open(REQUEST_FIFO, O_WRONLY);

    if (request_fd == -1) {
        perror("Cannot connect to server (is it running?)");
        unlink(req.response_fifo);
        return 1;
    }

    // Send request structure
    ssize_t sent = write(request_fd, &req, sizeof(req));

    close(request_fd);

    if (sent != sizeof(req)) {
        perror("Send request");
        unlink(req.response_fifo);
        return 1;
    }

    printf("\nRequest sent successfully.\n");
    printf("Waiting for server response...\n");

    // Receive server response
    response_fd = open(req.response_fifo, O_RDONLY);

    if (response_fd == -1) {
        perror("Open response FIFO");
        unlink(req.response_fifo);
        return 1;
    }

    ssize_t received = read(
        response_fd,
        response,
        sizeof(response) - 1
    );

    close(response_fd);
    unlink(req.response_fifo);

    if (received <= 0) {
        printf("No response received from server.\n");
        return 1;
    }

    response[received] = '\0';

    printf("\n====================================\n");
    printf("          SERVER RESPONSE           \n");
    printf("====================================\n");

    printf("%s\n", response);

    printf("====================================\n");

    return 0;
}
