
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <signal.h>
#include <errno.h>

#define REQUEST_FIFO "/tmp/smartlab_request"
#define PC_COUNT 5
#define QUEUE_SIZE 20
#define RESPONSE_SIZE 1024

typedef struct {
    char action[16];
    int student_id;
    int pc_number;
    char response_fifo[128];
} Request;

typedef struct {
    int student_id;
    int pc_number;
} QueueItem;

typedef struct {
    int computers[PC_COUNT];
    int owners[PC_COUNT];
    QueueItem queue[QUEUE_SIZE];
    int queue_count;
    sem_t lock;
} SharedData;

static SharedData *shared = NULL;

/* Reap completed child processes */
static void reap_children(int signal_number) {
    (void)signal_number;

    while (waitpid(-1, NULL, WNOHANG) > 0) {
    }
}

/* Check whether student is already waiting */
static int queue_contains(int student_id, int pc_number) {
    for (int i = 0; i < shared->queue_count; i++) {
        if (shared->queue[i].student_id == student_id &&
            shared->queue[i].pc_number == pc_number) {
            return 1;
        }
    }

    return 0;
}

/* Check whether student already owns any PC */
static int student_owns_pc(int student_id, int *pc_number) {
    for (int i = 0; i < PC_COUNT; i++) {
        if (shared->computers[i] == 1 &&
            shared->owners[i] == student_id) {

            *pc_number = i + 1;
            return 1;
        }
    }

    return 0;
}

/* Add student to waiting queue */
static int enqueue(int student_id, int pc_number) {
    if (shared->queue_count >= QUEUE_SIZE ||
        queue_contains(student_id, pc_number)) {
        return 0;
    }

    shared->queue[shared->queue_count].student_id = student_id;
    shared->queue[shared->queue_count].pc_number = pc_number;

    shared->queue_count++;

    return 1;
}

/* Remove first waiting student for a specific PC */
static int dequeue_for_pc(int pc_number, int *student_id) {
    for (int i = 0; i < shared->queue_count; i++) {

        if (shared->queue[i].pc_number == pc_number) {

            *student_id = shared->queue[i].student_id;

            for (int j = i; j < shared->queue_count - 1; j++) {
                shared->queue[j] = shared->queue[j + 1];
            }

            shared->queue_count--;

            return 1;
        }
    }

    return 0;
}

/* Generate complete laboratory status */
static void make_status(char *response, size_t size) {
    size_t used = 0;
    int available = 0;
    int occupied = 0;

    used += (size_t)snprintf(
        response + used, size - used,
        "SMARTLAB STATUS\n"
    );

    for (int i = 0; i < PC_COUNT; i++) {

        if (shared->computers[i] == 0) {

            available++;

            used += (size_t)snprintf(
                response + used, size - used,
                "PC %d: AVAILABLE\n", i + 1
            );

        } else {

            occupied++;

            used += (size_t)snprintf(
                response + used, size - used,
                "PC %d: OCCUPIED (Student %d)\n",
                i + 1, shared->owners[i]
            );
        }

        if (used >= size) return;
    }

    used += (size_t)snprintf(
        response + used, size - used,
        "Available: %d | Occupied: %d | Waiting: %d\n",
        available, occupied, shared->queue_count
    );

    if (shared->queue_count > 0 && used < size) {

        used += (size_t)snprintf(
            response + used, size - used,
            "WAITING QUEUE:\n"
        );

        for (int i = 0;
             i < shared->queue_count && used < size;
             i++) {

            used += (size_t)snprintf(
                response + used, size - used,
                "%d. Student %d waiting for PC %d\n",
                i + 1,
                shared->queue[i].student_id,
                shared->queue[i].pc_number
            );
        }
    }
}

/* Handle client request */
static void handle_request(const Request *req) {

    char response[RESPONSE_SIZE] = {0};

    if (sem_wait(&shared->lock) == -1) {

        snprintf(
            response, sizeof(response),
            "Server synchronization error."
        );

    } else {

        /* REQUEST COMPUTER */
        if (strcmp(req->action, "REQUEST") == 0) {

            if (req->student_id <= 0) {

                snprintf(response, sizeof(response),
                         "Invalid student ID.");

            } else if (req->pc_number < 1 ||
                       req->pc_number > PC_COUNT) {

                snprintf(response, sizeof(response),
                         "Invalid PC number.");

            } else {

                int index = req->pc_number - 1;
                int owned_pc = 0;

                /* Prevent students from requesting another PC
                   when they already own one */
                if (student_owns_pc(req->student_id, &owned_pc)) {

                    snprintf(
                        response, sizeof(response),
                        "REJECTED: Student %d already owns PC %d.",
                        req->student_id, owned_pc
                    );

                } else if (shared->computers[index] == 0) {

                    /* Allocate available PC */
                    shared->computers[index] = 1;
                    shared->owners[index] = req->student_id;

                    snprintf(
                        response, sizeof(response),
                        "SUCCESS: PC %d allocated to Student %d.",
                        req->pc_number, req->student_id
                    );

                } else if (queue_contains(
                               req->student_id, req->pc_number)) {

                    snprintf(
                        response, sizeof(response),
                        "REJECTED: Student %d is already waiting for PC %d.",
                        req->student_id, req->pc_number
                    );

                } else if (enqueue(
                               req->student_id, req->pc_number)) {

                    snprintf(
                        response, sizeof(response),
                        "PC %d is occupied. Student %d added to queue. Position: %d.",
                        req->pc_number,
                        req->student_id,
                        shared->queue_count
                    );

                } else {

                    snprintf(
                        response, sizeof(response),
                        "REJECTED: Queue is full or duplicate request."
                    );
                }
            }
        }

        /* RELEASE COMPUTER */
        else if (strcmp(req->action, "RELEASE") == 0) {

            if (req->student_id <= 0) {

                snprintf(response, sizeof(response),
                         "Invalid student ID.");

            } else if (req->pc_number < 1 ||
                       req->pc_number > PC_COUNT) {

                snprintf(response, sizeof(response),
                         "Invalid PC number.");

            } else {

                int index = req->pc_number - 1;

                if (shared->computers[index] == 0) {

                    snprintf(
                        response, sizeof(response),
                        "PC %d is already available.",
                        req->pc_number
                    );

                } else if (shared->owners[index] != req->student_id) {

                    snprintf(
                        response, sizeof(response),
                        "REJECTED: Student %d does not own PC %d.",
                        req->student_id, req->pc_number
                    );

                } else {

                    int waiting_student = 0;

                    if (dequeue_for_pc(
                            req->pc_number, &waiting_student)) {

                        shared->computers[index] = 1;
                        shared->owners[index] = waiting_student;

                        snprintf(
                            response, sizeof(response),
                            "PC %d released by Student %d and automatically allocated to waiting Student %d.",
                            req->pc_number,
                            req->student_id,
                            waiting_student
                        );

                    } else {

                        shared->computers[index] = 0;
                        shared->owners[index] = 0;

                        snprintf(
                            response, sizeof(response),
                            "SUCCESS: PC %d released and is now available.",
                            req->pc_number
                        );
                    }
                }
            }
        }

        /* VIEW LABORATORY STATUS */
        else if (strcmp(req->action, "STATUS") == 0) {

            make_status(response, sizeof(response));

        } else {

            snprintf(
                response, sizeof(response),
                "Unknown client action."
            );
        }

        sem_post(&shared->lock);
    }

    /* Send response to client */
    int response_fd = open(req->response_fifo, O_WRONLY);

    if (response_fd == -1) {
        perror("open response FIFO");
        return;
    }

    write(response_fd, response, strlen(response) + 1);

    close(response_fd);
}

/* Read complete request structure */
static int read_full(int fd, void *buffer, size_t length) {

    size_t total = 0;
    char *p = (char *)buffer;

    while (total < length) {

        ssize_t n = read(fd, p + total, length - total);

        if (n == 0) return 0;

        if (n < 0) {

            if (errno == EINTR) continue;

            return -1;
        }

        total += (size_t)n;
    }

    return 1;
}

/* Main server */
int main(void) {

    shared = mmap(
        NULL,
        sizeof(SharedData),
        PROT_READ | PROT_WRITE,
        MAP_SHARED | MAP_ANONYMOUS,
        -1,
        0
    );

    if (shared == MAP_FAILED) {

        perror("mmap");

        return 1;
    }

    memset(shared, 0, sizeof(*shared));

    /* Initial demo PC status */
    int initial_status[PC_COUNT] = {
        0, 1, 0, 0, 1
    };

    int initial_owners[PC_COUNT] = {
        0, 2002, 0, 0, 5005
    };

    memcpy(
        shared->computers,
        initial_status,
        sizeof(initial_status)
    );

    memcpy(
        shared->owners,
        initial_owners,
        sizeof(initial_owners)
    );

    /* Process-shared semaphore */
    if (sem_init(&shared->lock, 1, 1) == -1) {

        perror("sem_init");

        munmap(shared, sizeof(SharedData));

        return 1;
    }

    /* Handle child processes */
    struct sigaction sa;

    memset(&sa, 0, sizeof(sa));

    sa.sa_handler = reap_children;

    sigemptyset(&sa.sa_mask);

    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;

    if (sigaction(SIGCHLD, &sa, NULL) == -1) {

        perror("sigaction");

        return 1;
    }

    /* Create request FIFO */
    unlink(REQUEST_FIFO);

    if (mkfifo(REQUEST_FIFO, 0666) == -1) {

        perror("mkfifo request FIFO");

        return 1;
    }

    printf("====================================\n");
    printf("       SMARTLAB SERVER STARTED      \n");
    printf("====================================\n");

    printf("Waiting for client requests...\n");

    printf("Demo owners: PC 2 -> 2002, PC 5 -> 5005\n");

    printf("Duplicate ownership validation: ENABLED\n");

    printf("FIFO queue management: ENABLED\n");

    printf("Semaphore synchronization: ENABLED\n");

    printf("Press Ctrl+C to stop the server.\n");

    /* Server main loop */
    while (1) {

        int request_fd = open(REQUEST_FIFO, O_RDONLY);

        if (request_fd == -1) {

            if (errno == EINTR) continue;

            perror("open request FIFO");

            continue;
        }

        Request req;

        int result = read_full(
            request_fd,
            &req,
            sizeof(req)
        );

        close(request_fd);

        if (result != 1) continue;

        pid_t pid = fork();

        if (pid < 0) {

            perror("fork");

            continue;
        }

        if (pid == 0) {

            handle_request(&req);

            _exit(0);
        }
    }

    return 0;
}
