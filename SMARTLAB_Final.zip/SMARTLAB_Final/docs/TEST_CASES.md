# SMARTLAB Test Cases

| ID | Action | Input | Expected result |
|---|---|---|---|
| TC01 | Request available PC | Student 101, PC 1 | PC 1 allocated to 101 |
| TC02 | Request occupied PC | Student 102, PC 2 | Student 102 joins queue |
| TC03 | Correct owner releases PC | Student 2002, PC 2 | PC 2 allocated to Student 102 |
| TC04 | Wrong student releases PC | Student 999, PC 1 | Release rejected |
| TC05 | View status | Any student ID | PCs, owners, totals and queue displayed |
| TC06 | Invalid PC | PC 9 | Invalid PC number |
| TC07 | Queue duplicate | Same student requests same occupied PC twice | Duplicate request rejected |
