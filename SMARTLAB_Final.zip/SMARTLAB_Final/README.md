# SMARTLAB — Smart Computer Laboratory Resource Management System

## Project overview
SMARTLAB is a command-line client-server application that manages five laboratory computers. Students can request a computer, wait in a queue if it is occupied, release a computer they own, and view the laboratory status.

## Technologies
- C programming language
- Ubuntu/Linux
- GCC compiler
- Named Pipes (FIFOs)
- `fork()` processes
- Shared memory (`mmap`)
- POSIX semaphore

## Operating Systems concepts
1. IPC: named pipes carry requests and responses between clients and server.
2. Process management: the server creates a child process with `fork()` for each request.
3. Shared memory: child processes access the same computer and queue data.
4. Synchronization: a process-shared semaphore protects shared data.
5. Scheduling/data structure: a bounded waiting queue stores students waiting for a particular PC.

## Files
- `src/server.c` — server, shared state, queue, allocation, synchronization
- `src/client.c` — client menu and FIFO communication
- `Makefile` — build and clean commands

## Requirements
Ubuntu/Linux, GCC, and `make`.

Install build tools if required:
```bash
sudo apt update
sudo apt install build-essential
```

## Compile
From the SMARTLAB folder:
```bash
make
```

Or compile manually:
```bash
gcc -Wall -Wextra -std=c11 -D_GNU_SOURCE src/server.c -o server -pthread
gcc -Wall -Wextra -std=c11 src/client.c -o client
```

## Run
Open Terminal 1:
```bash
cd ~/SMARTLAB
./server
```

Open Terminal 2:
```bash
cd ~/SMARTLAB
./client
```

Run `./client` again for every new operation. Keep the server running.

## Demonstration starting state
The server starts with:
- PC 1: available
- PC 2: occupied by Student 2002
- PC 3: available
- PC 4: available
- PC 5: occupied by Student 5005

The two initial owner IDs are demonstration data.

## Suggested test sequence

### Test A — Request an available PC
Choose option 1, enter Student ID `101`, PC `1`.
Expected: PC 1 is allocated to Student 101.

### Test B — Request an occupied PC
Choose option 1, enter Student ID `102`, PC `2`.
Expected: Student 102 is added to the waiting queue.

### Test C — Release by the correct owner
Choose option 2, enter Student ID `2002`, PC `2`.
Expected: PC 2 is automatically allocated to waiting Student 102.

### Test D — Reject an incorrect release
Choose option 2, enter Student ID `999`, PC `1`.
Expected: request rejected because Student 999 does not own PC 1.

### Test E — View status
Choose option 3 and enter any student ID.
Expected: the server lists each PC, current owner, available/occupied totals, and waiting queue.

## Important implementation notes
- The queue capacity is 20 entries.
- The queue is FIFO among students waiting for the same PC. When a PC is released, the earliest matching request for that PC is selected.
- The server's state exists in shared memory and resets when the server is stopped/restarted.
- The server tells the releasing client which waiting student received the PC. The waiting client is not actively notified; the student can check status to see the allocation.
- This is an academic prototype, not a production access-control system. It does not use login authentication or persistent database storage.
- The demo uses fixed initial owners for PC 2 and PC 5 so release validation can be demonstrated.

## Stop and clean up
Stop the server with `Ctrl+C`. Then, if needed:
```bash
make clean
```
Only run `make clean` after stopping the server.

## Team work split suggestion
- Member 1: server, process creation, shared memory, semaphore
- Member 2: client, FIFO request/response, testing
- Member 3: queue logic, documentation, test cases, presentation

## Future GUI integration
A later GUI can be built in Python/Streamlit. It should call the client through a controlled interface or use a separate API layer. Do not let the GUI directly modify shared memory.


## Streamlit GUI (included)
The graphical interface is in `gui/app.py`. It does not replace the C backend: Streamlit runs the existing compiled C client as a subprocess, and the C client communicates with the server through named pipes.

### Install GUI dependency
From the project root:
```bash
python3 -m pip install -r gui/requirements.txt
```

If pip reports an externally-managed-environment error on Ubuntu, use a virtual environment:
```bash
sudo apt install python3-venv
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r gui/requirements.txt
```

### Start the application
Terminal 1 — start the C server:
```bash
cd ~/SMARTLAB_Final
./server
```

Terminal 2 — start the Streamlit GUI:
```bash
cd ~/SMARTLAB_Final
source .venv/bin/activate   # only if you created the virtual environment
./run_gui.sh
```

Streamlit will print a local address, usually `http://localhost:8501`. Open that address in your browser.

### GUI sections
- Dashboard
- Request Computer
- Release Computer
- Laboratory Status

### Architecture
Browser → Streamlit GUI (Python) → C client subprocess → request FIFO → C server → shared memory + semaphore → response FIFO → Streamlit GUI

The GUI requires the C server to be running separately. The C server remains responsible for allocation and synchronization.
