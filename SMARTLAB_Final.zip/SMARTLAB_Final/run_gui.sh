#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -x "./client" ]; then
    echo "C client not found. Run 'make' in this folder first."
    exit 1
fi
python3 -m streamlit run gui/app.py
