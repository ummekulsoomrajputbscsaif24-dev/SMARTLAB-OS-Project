import re
import subprocess
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
CLIENT = ROOT / "client"

st.set_page_config(
    page_title="SMARTLAB | Laboratory Management",
    page_icon="💻",
    layout="wide",
)

st.markdown(
    """
    <style>
    .main {background: #f6f8fc;}
    .block-container {padding-top: 2rem; max-width: 1150px;}
    .hero {
        padding: 1.5rem 1.7rem;
        border-radius: 18px;
        background: linear-gradient(120deg, #172554, #1d4ed8);
        color: white;
        margin-bottom: 1.2rem;
    }
    .hero h1 {color: white; margin: 0;}
    .hero p {color: #dbeafe; margin-bottom: 0;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
      <h1>SMARTLAB</h1>
      <p>Smart Computer Laboratory Resource Management System</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.caption("Operating Systems Semester Project • C backend + Python Streamlit interface")

if not CLIENT.exists():
    st.error("C client executable not found. Compile the project first using `make` from the project root.")
    st.stop()

st.sidebar.title("Navigation")
page = st.sidebar.radio("Open section", ["Dashboard", "Request Computer", "Release Computer", "Laboratory Status"])
st.sidebar.info("Make sure the C server is running in a separate terminal: `./server`")

def call_backend(choice: int, student_id: int, pc_number: int = 0):
    """Run the existing C client and pass menu answers through standard input."""
    values = [str(choice), str(student_id)]
    if choice in (1, 2):
        values.append(str(pc_number))
    payload = "\n".join(values) + "\n"

    try:
        result = subprocess.run(
            [str(CLIENT)],
            input=payload,
            text=True,
            capture_output=True,
            timeout=15,
            cwd=str(ROOT),
        )
    except subprocess.TimeoutExpired:
        return False, "The request timed out. Check that the SMARTLAB server is running."
    except OSError as exc:
        return False, f"Could not start the C client: {exc}"

    output = (result.stdout or "") + (result.stderr or "")
    if result.returncode != 0:
        return False, output.strip() or "The C client returned an error."
    match = re.search(r"----- SERVER RESPONSE -----\s*(.*)", output, re.S)
    if match:
        return True, match.group(1).strip()
    return False, output.strip() or "No response received."

def show_result(ok, message):
    if ok:
        st.success(message)
    else:
        st.error(message)

if page == "Dashboard":
    st.subheader("Laboratory Dashboard")
    st.write("Use the sections in the sidebar to request or release a computer and view live laboratory status.")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("### Computer allocation")
        st.write("Students can request an available computer. If their selected PC is occupied, they can join its waiting queue.")
    with c2:
        st.markdown("### Automatic allocation")
        st.write("When the current owner releases a PC, the first student waiting for that PC receives it automatically.")
    st.info("The initial demonstration state is configured in the C server: PC 2 belongs to Student 2002 and PC 5 belongs to Student 5005.")
    if st.button("Refresh laboratory status", type="primary"):
        ok, message = call_backend(3, 0)
        show_result(ok, message)

elif page == "Request Computer":
    st.subheader("Request a Computer")
    with st.form("request_form"):
        student_id = st.number_input("Student ID", min_value=1, step=1, value=101)
        pc_number = st.selectbox("Choose Computer", [1, 2, 3, 4, 5])
        submitted = st.form_submit_button("Submit Request", type="primary")
    if submitted:
        ok, message = call_backend(1, int(student_id), int(pc_number))
        show_result(ok, message)

elif page == "Release Computer":
    st.subheader("Release a Computer")
    st.write("Only the student currently recorded as the owner can release that computer.")
    with st.form("release_form"):
        student_id = st.number_input("Student ID", min_value=1, step=1, value=2002)
        pc_number = st.selectbox("Computer to Release", [1, 2, 3, 4, 5])
        submitted = st.form_submit_button("Release Computer", type="primary")
    if submitted:
        ok, message = call_backend(2, int(student_id), int(pc_number))
        show_result(ok, message)

elif page == "Laboratory Status":
    st.subheader("Live Laboratory Status")
    st.write("Ask the C server for the current computer owners and waiting queue.")
    if st.button("Load Status", type="primary"):
        ok, message = call_backend(3, 0)
        if ok:
            st.success("Status received from SMARTLAB server.")
            st.code(message, language="text")
        else:
            st.error(message)
    st.caption("Status is held in shared memory while the server is running. It resets when the server is restarted.")

st.divider()
st.caption("SMARTLAB • Demonstration build • C handles allocation, processes, shared memory and synchronization.")
