
import streamlit as st
import subprocess
import re
from pathlib import Path

# ---------------- PAGE CONFIG ----------------
st.set_page_config(
    page_title="SMARTLAB | Lab Management",
    page_icon="💻",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------- PATHS ----------------
BASE_DIR = Path(__file__).resolve().parent.parent
CLIENT_PATH = BASE_DIR / "client"

# ---------------- CUSTOM CSS ----------------
st.markdown("""
<style>
.stApp {
    background: #f3f6fc;
}

[data-testid="stSidebar"] {
    background: #101b35;
}

[data-testid="stSidebar"] * {
    color: white !important;
}

.main-title {
    font-size: 34px;
    font-weight: 800;
    color: #172554;
}

.subtitle {
    color: #64748b;
    font-size: 15px;
}

.hero {
    background: linear-gradient(120deg, #172554, #2563eb);
    padding: 30px;
    border-radius: 18px;
    color: white;
    margin-bottom: 25px;
}

.hero h1 {
    color: white;
    font-size: 30px;
}

.hero p {
    color: #dbeafe;
}

.metric-card {
    background: white;
    padding: 22px;
    border-radius: 15px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 3px 12px rgba(15,23,42,0.04);
}

.metric-label {
    color: #64748b;
    font-size: 14px;
}

.metric-number {
    color: #172554;
    font-size: 30px;
    font-weight: 800;
}

.pc-card {
    background: white;
    padding: 20px;
    border-radius: 15px;
    border: 1px solid #e2e8f0;
    margin-bottom: 12px;
}

.pc-name {
    color: #172554;
    font-size: 19px;
    font-weight: 700;
}

.pc-status {
    font-size: 14px;
    font-weight: 700;
}

div.stButton > button {
    border-radius: 9px;
    font-weight: 600;
}
</style>
""", unsafe_allow_html=True)


# ---------------- BACKEND FUNCTION ----------------
def run_backend(action, student_id=0, pc_number=0):

    try:
        if action == "REQUEST":
            input_data = f"1\n{student_id}\n{pc_number}\n"

        elif action == "RELEASE":
            input_data = f"2\n{student_id}\n{pc_number}\n"

        elif action == "STATUS":
            input_data = "3\n"

        else:
            return False, "Invalid action."

        result = subprocess.run(
            [str(CLIENT_PATH)],
            input=input_data,
            text=True,
            capture_output=True,
            cwd=str(BASE_DIR),
            timeout=15
        )

        output = result.stdout.strip()
        error = result.stderr.strip()

        if result.returncode != 0:
            return False, output + ("\n" + error if error else "")

        lower_output = output.lower()

        rejection_messages = [
            "rejected:",
            "request rejected:",
            "invalid pc",
            "unknown client action",
            "synchronization error",
            "no response received",
            "invalid student id"
        ]

        if any(message in lower_output for message in rejection_messages):
            return False, output

        if "server response" not in lower_output:
            return False, output or error or "No valid server response."

        return True, output

    except subprocess.TimeoutExpired:
        return False, "Server response timeout. Check whether server is running."

    except FileNotFoundError:
        return False, "C client executable not found. Compile client first."

    except Exception as e:
        return False, str(e)


# ---------------- STATUS PARSER ----------------
def extract_status(output):

    statuses = {}

    for line in output.splitlines():

        match = re.search(
            r"PC\s*(\d+):\s*(AVAILABLE|OCCUPIED)",
            line,
            re.IGNORECASE
        )

        if match:

            pc_number = int(match.group(1))
            state = match.group(2).upper()

            owner_match = re.search(
                r"Student\s+(\d+)",
                line,
                re.IGNORECASE
            )

            statuses[pc_number] = {
                "state": state,
                "owner": owner_match.group(1) if owner_match else None
            }

    return statuses


# ---------------- SESSION STATE ----------------
if "last_output" not in st.session_state:
    st.session_state.last_output = "No recent activity."

if "last_success" not in st.session_state:
    st.session_state.last_success = None

if "last_action" not in st.session_state:
    st.session_state.last_action = "None"

if "navigation" not in st.session_state:
    st.session_state.navigation = "Dashboard"


# ---------------- NAVIGATION CALLBACK ----------------
def go_to_page(page_name):
    st.session_state.navigation = page_name


# ---------------- SIDEBAR ----------------
with st.sidebar:

    st.markdown("# 💻 SMARTLAB")
    st.caption("Smart Computer Laboratory")
    st.divider()

    page = st.radio(
        "NAVIGATION",
        [
            "Dashboard",
            "Request Computer",
            "Release Computer",
            "System Status"
        ],
        key="navigation",
        label_visibility="visible"
    )

    st.divider()

    st.markdown("### System Information")
    st.caption("Operating System: Linux")
    st.caption("Backend: C Programming")
    st.caption("Communication: FIFO")
    st.caption("Synchronization: Semaphore")
    st.caption("Process Management: fork()")

    st.divider()

    st.caption("SMARTLAB Project | OS Semester Project")


# ---------------- HEADER ----------------
st.markdown(
    '<div class="hero">'
    '<h1>Smart Computer Laboratory</h1>'
    '<p>Manage laboratory computers, student requests and system availability.</p>'
    '</div>',
    unsafe_allow_html=True
)


# ---------------- DASHBOARD ----------------
if page == "Dashboard":

    st.markdown(
        '<div class="main-title">Dashboard Overview</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">Welcome to your laboratory management system.</div>',
        unsafe_allow_html=True
    )

    # Get live status from C server
    status_success, status_output = run_backend("STATUS")

    statuses = extract_status(status_output) if status_success else {}

    # Calculate PC availability
    available = sum(
        1 for pc in statuses.values()
        if pc["state"] == "AVAILABLE"
    )

    occupied = sum(
        1 for pc in statuses.values()
        if pc["state"] == "OCCUPIED"
    )

    # Calculate waiting queue
    waiting_match = re.search(
        r"Waiting:\s*(\d+)",
        status_output,
        re.IGNORECASE
    )

    waiting = int(waiting_match.group(1)) if waiting_match else 0

    # Server connection warning
    if not status_success:
        st.warning("Live server status unavailable.")
        st.code(status_output)

    # Dashboard metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Total Computers", 5)

    with col2:
        st.metric(
            "Available PCs",
            available if status_success else "—"
        )

    with col3:
        st.metric(
            "Occupied PCs",
            occupied if status_success else "—"
        )

    with col4:
        st.metric(
            "Waiting Queue",
            waiting if status_success else "—"
        )

    st.divider()

    # Computer Laboratory
    st.subheader("🖥️ Computer Laboratory")

    pc_cols = st.columns(3)

    for i in range(1, 6):

        with pc_cols[(i - 1) % 3]:

            pc = statuses.get(i)

            if pc:

                if pc["state"] == "AVAILABLE":

                    st.success(f"🖥️ PC {i} — AVAILABLE")
                    st.caption("Ready for student allocation.")

                else:

                    st.error(f"🖥️ PC {i} — OCCUPIED")

                    if pc["owner"]:
                        st.caption(
                            f"Currently used by Student {pc['owner']}"
                        )
                    else:
                        st.caption("Currently occupied.")

            else:

                st.warning(f"🖥️ PC {i} — UNKNOWN")

    st.divider()

    # Quick Actions
    st.subheader("⚡ Quick Actions")

    quick1, quick2, quick3 = st.columns(3)

    with quick1:

        st.button(
            "➕ Request a PC",
            use_container_width=True,
            on_click=go_to_page,
            args=("Request Computer",)
        )

    with quick2:

        st.button(
            "↩️ Release a PC",
            use_container_width=True,
            on_click=go_to_page,
            args=("Release Computer",)
        )

    with quick3:

        st.button(
            "🔄 Check Status",
            use_container_width=True,
            on_click=go_to_page,
            args=("System Status",)
        )


# ---------------- REQUEST COMPUTER ----------------
elif page == "Request Computer":

    st.title("➕ Request a Computer")

    st.write(
        "Submit a student request for a laboratory computer."
    )

    with st.form("request_form"):

        student_id_input = st.text_input(
            "Student ID",
            placeholder="Enter a positive student ID"
        )

        pc_number_input = st.text_input(
            "Computer Number (1-5)",
            placeholder="Enter PC number"
        )

        submitted = st.form_submit_button(
            "Submit Request",
            use_container_width=True
        )

    if submitted:

        try:
            student_id = int(student_id_input.strip())
            pc_number = int(pc_number_input.strip())

            if student_id <= 0:
                st.error("Invalid Student ID. Enter a number greater than 0.")

            elif pc_number < 1 or pc_number > 5:
                st.error("Invalid PC Number. Enter a number from 1 to 5.")

            else:
                success, output = run_backend(
                    "REQUEST",
                    student_id,
                    pc_number
                )

                st.session_state.last_output = output
                st.session_state.last_success = success
                st.session_state.last_action = "Request Computer"

                if success:
                    st.success("Request sent to the C backend.")
                else:
                    st.error("Request failed.")

                st.code(output)

        except ValueError:
            st.error("Please enter valid numeric values.")


# ---------------- RELEASE COMPUTER ----------------
elif page == "Release Computer":

    st.title("↩️ Release a Computer")

    st.write(
        "Submit a release request for a laboratory computer."
    )

    with st.form("release_form"):

        student_id_input = st.text_input(
            "Student ID",
            placeholder="Enter a positive student ID",
            key="release_student"
        )

        pc_number_input = st.text_input(
            "Computer Number (1-5)",
            placeholder="Enter PC number",
            key="release_pc"
        )

        submitted = st.form_submit_button(
            "Release Computer",
            use_container_width=True
        )

    if submitted:

        try:
            student_id = int(student_id_input.strip())
            pc_number = int(pc_number_input.strip())

            if student_id <= 0:
                st.error("Invalid Student ID. Enter a number greater than 0.")

            elif pc_number < 1 or pc_number > 5:
                st.error("Invalid PC Number. Enter a number from 1 to 5.")

            else:
                success, output = run_backend(
                    "RELEASE",
                    student_id,
                    pc_number
                )

                st.session_state.last_output = output
                st.session_state.last_success = success
                st.session_state.last_action = "Release Computer"

                if success:
                    st.success("Release request sent to the C backend.")
                else:
                    st.error("Release request failed.")

                st.code(output)

        except ValueError:
            st.error("Please enter valid numeric values.")


# ---------------- SYSTEM STATUS ----------------
elif page == "System Status":

    st.title("📊 System Status")

    st.write(
        "Retrieve the latest status from the C server."
    )

    if st.button(
        "🔄 Refresh System Status",
        use_container_width=True
    ):

        success, output = run_backend("STATUS")

        st.session_state.last_output = output
        st.session_state.last_success = success
        st.session_state.last_action = "System Status"

        if success:
            st.success("Status request completed.")
        else:
            st.error("Could not retrieve status.")

    st.subheader("Backend Response")

    st.code(st.session_state.last_output)

    if st.session_state.last_success is False:

        st.warning(
            "Check that the C server is running in another terminal."
        )


# ---------------- RECENT ACTIVITY ----------------
st.divider()

st.subheader("🕒 Latest Activity")

st.write(
    "**Last action:**",
    st.session_state.last_action
)

st.write("**Latest response:**")

st.code(st.session_state.last_output)
